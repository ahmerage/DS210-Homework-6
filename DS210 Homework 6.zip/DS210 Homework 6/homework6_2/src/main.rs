fn main() {
    let n = 100;
    let mut F: Vec<u128> = vec![0; n + 1];

    for i in 0..=n {
        if i == 0 {
            F[i] = 0;
        } else if i == 1 {
            F[i] = 1;
        } else {
            F[i] = F[i - 1] + F[i - 2];
        }
    }

    for i in 0..=n {
        println!("F[{}]: {}", i, F[i]);
    }
}