use std::io;

fn main() {
    println!("Enter a non-negative integer (k):");

    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Failed to read line");
    let input = input.trim();
    
    let k: u32 = input.parse().expect("Not a valid non-negative integer!");

    let result = calculate_sum_of_squares(k);

    println!("Sum of squares from 1 to {} is: {}", k, result);
}

fn calculate_sum_of_squares(k: u32) -> u64 {
    let mut sum: u64 = 0;

    for i in 1..=k as u64 {
        sum += i * i;
    }

    sum
}
